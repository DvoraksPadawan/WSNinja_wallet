# WallStreetNinja Frontend

## Environment Variables

All variables need to be set.

**REACT_APP_BACKEND_URL**  
Url of the WallStreetNinja Backend

**REACT_APP_TESTING**  
Activates testing mode. Off = 0, On = 1


