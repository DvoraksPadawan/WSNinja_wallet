export const CoinList = [
   {
      from: {
         name: 'BNB',
         unit: 'BNB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Chi Gastoken by 1inch',
         unit: 'CHI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PancakeSwap Token',
         unit: 'CAKE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BUSD Token',
         unit: 'BUSD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ethereum Token',
         unit: 'ETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BTCB Token',
         unit: 'BTCB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'AUTOv2',
         unit: 'AUTO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSCX',
         unit: 'BSCX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'bDollar',
         unit: 'BDO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DOT',
         unit: 'DOT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Wrapped UST Token',
         unit: 'UST',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'VAI Stablecoin',
         unit: 'VAI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Uniswap',
         unit: 'UNI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ChainLink Token',
         unit: 'LINK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'USD Coin',
         unit: 'USDC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'zSeedToken',
         unit: 'zSEED',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Dai Token',
         unit: 'DAI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Band Protocol Token',
         unit: 'BAND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Woonkly Power',
         unit: 'WOOP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'bDollar Share',
         unit: 'sBDO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cardano Token',
         unit: 'ADA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SafePal Token',
         unit: 'SFP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Fuel Token',
         unit: 'Fuel',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus',
         unit: 'XVS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Trust Wallet',
         unit: 'TWT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Goose Golden Egg',
         unit: 'EGG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'yearn.finance',
         unit: 'YFI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Berry Tributes',
         unit: 'BRY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Swipe',
         unit: 'SXP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'XRP Token',
         unit: 'XRP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Compound Coin',
         unit: 'COMP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ACryptoS',
         unit: 'ACS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ferengi Vaults',
         unit: 'EARS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Reef.finance',
         unit: 'REEF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'AlphaToken',
         unit: 'ALPHA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Injective Protocol',
         unit: 'INJ',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Kebab Token',
         unit: 'KEBAB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Wrapped SOTE',
         unit: 'wSOTE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'EOS Token',
         unit: 'EOS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bunny Token',
         unit: 'BUNNY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Litecoin Token',
         unit: 'LTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Litentry',
         unit: 'LIT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bitcoin Cash Token',
         unit: 'BCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Helmet.insure Governance Token',
         unit: 'Helmet',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CafeSwap Token',
         unit: 'BREW',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Frontier Token',
         unit: 'FRONT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'StandardBTCHashrateToken',
         unit: 'BTCST',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Filecoin',
         unit: 'FIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ditto',
         unit: 'DITTO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cosmos Token',
         unit: 'ATOM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: '1INCH Token',
         unit: '1INCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus SXP',
         unit: 'vSXP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus USDC',
         unit: 'vUSDC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus USDT',
         unit: 'vUSDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus BUSD',
         unit: 'vBUSD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus BNB',
         unit: 'vBNB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus XVS',
         unit: 'vXVS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus BTC',
         unit: 'vBTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus ETH',
         unit: 'vETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus LTC',
         unit: 'vLTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus XRP',
         unit: 'vXRP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus BCH',
         unit: 'vBCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus DOT',
         unit: 'vDOT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus LINK',
         unit: 'vLINK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus BETH',
         unit: 'vBETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus DAI',
         unit: 'vDAI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus FIL',
         unit: 'vFIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Binance Beacon ETH',
         unit: 'BETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BakeryToken',
         unit: 'BAKE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renBTC',
         unit: 'renBTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renBCH',
         unit: 'renBCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renZEC',
         unit: 'renZEC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renFIL',
         unit: 'renFIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renLUNA',
         unit: 'renLUNA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renDOGE',
         unit: 'renDOGE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'renDGB',
         unit: 'renDGB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ApeSwapFinance Banana',
         unit: 'BANANA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Maker',
         unit: 'MKR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Zcash Token',
         unit: 'ZEC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'NEAR Protocol',
         unit: 'NEAR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ethereum Classic',
         unit: 'ETC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ontology Token',
         unit: 'ONT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Basic Attention Token',
         unit: 'BAT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Paxos Standard',
         unit: 'PAX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DODO bird',
         unit: 'DODO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bitcoin Cash ABC',
         unit: 'BCHA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'IoTeX Network',
         unit: 'IOTX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Wrapped MIR Token',
         unit: 'MIR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ankr',
         unit: 'ANKR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Linear Token',
         unit: 'LINA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MATH Token',
         unit: 'MATH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ELF Token',
         unit: 'ELF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PAX Gold',
         unit: 'PAXG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Prometeus',
         unit: 'PROM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'YFII.finance Token',
         unit: 'YFII',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'LTO Network',
         unit: 'LTO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream',
         unit: 'CREAM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Spartan Protocol Token',
         unit: 'SPARTA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Anyswap-BEP20',
         unit: 'ANY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'JulSwap',
         unit: 'JulD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Burger Swap',
         unit: 'BURGER',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CertiK Token',
         unit: 'CTK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'StableX Token',
         unit: 'STAX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Token Club',
         unit: 'TCT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'FREE coin BSC',
         unit: 'FREE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CanYaCoin',
         unit: 'CAN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'fry.world',
         unit: 'FRIES',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cubiex',
         unit: 'CBIX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Billion Happiness',
         unit: 'BHC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Streamity',
         unit: 'STM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Spore Token',
         unit: 'SPORE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Keep3r BSC Network',
         unit: 'KP3RB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Seven Up Token',
         unit: '7UP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Phoswap',
         unit: 'PHO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bolt Dollar',
         unit: 'BTD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'cheesemaker.farm',
         unit: 'CHS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cross Finance',
         unit: 'CRP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Propel',
         unit: 'PROPEL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BIDR BEP20',
         unit: 'BIDR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Cardano Token',
         unit: 'crADA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'dForce',
         unit: 'DF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DOS Network Token BEP20',
         unit: 'DOS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'InnovativeBioresearchCoin',
         unit: 'INNBC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Jointer',
         unit: 'JNTR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Milk Protocol',
         unit: 'MILK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Squirrel Finance',
         unit: 'NUTS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'JULb',
         unit: 'JULb',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'beefy.finance',
         unit: 'BIFI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Dai Token',
         unit: 'crDAI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream YFI',
         unit: 'crYFI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream ChainLink Token',
         unit: 'crLINK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Uniswap',
         unit: 'crUNI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Cosmos Token',
         unit: 'crATOM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Cream',
         unit: 'crCREAM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Filecoin',
         unit: 'crFIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Ethereum Token',
         unit: 'crETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream XRP',
         unit: 'crXRP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Binance USD',
         unit: 'crBUSD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Bitcoin Cash Token',
         unit: 'crBCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Trust Wallet',
         unit: 'crTWT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream EOS Token',
         unit: 'crEOS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Tezos Token',
         unit: 'crXTZ',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Litecoin Token',
         unit: 'crLTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Tether USD',
         unit: 'crUSDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream BNB',
         unit: 'crBNB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Band Protocol Token',
         unit: 'crBAND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream Polkadot Token',
         unit: 'crDOT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream BTCB Token',
         unit: 'crBTCB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream USD Coin',
         unit: 'crUSDC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cream AlphaToken',
         unit: 'crALPHA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Dogecoin',
         unit: 'DOGE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Crow Token',
         unit: 'CROW',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Multiplier',
         unit: 'bMXX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ETHb',
         unit: 'ETHb',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'AlpacaToken',
         unit: 'ALPACA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Kangal',
         unit: 'bKANGAL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UBUToken',
         unit: 'UBU',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BELT Token',
         unit: 'BELT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Niubi Token',
         unit: 'NIU',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'dego.finance',
         unit: 'DEGO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Soup Share',
         unit: 'SOUPS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Soup',
         unit: 'SOUP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'bears.finance deflationary token',
         unit: 'BEAR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'FlourMix',
         unit: 'FLO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Midas Dollar',
         unit: 'MDO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Midas Dollar Share',
         unit: 'MDS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'WOWswap',
         unit: 'WOW',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Salt Token',
         unit: 'SALT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSCPAD.com',
         unit: 'BSCPAD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'bearn.fi',
         unit: 'BFI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Utile',
         unit: 'UTL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Fusible | Fusible.io',
         unit: 'FUSII',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CenterPrime',
         unit: 'CPX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Meowth Token',
         unit: 'MEOWTH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pasta Token',
         unit: 'PASTA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SparkPoint',
         unit: 'bSRK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Contentos',
         unit: 'COS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Curate on BSC',
         unit: 'XCUR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'AlpaToken',
         unit: 'ALPA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Juggernaut DeFi',
         unit: 'JGN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Nominex',
         unit: 'NMX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DANGO',
         unit: 'DANGO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Borshchik',
         unit: 'BORSHCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bolt Share',
         unit: 'BTS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'APETools.gg',
         unit: 'NANA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Moola',
         unit: 'MLA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'HARD',
         unit: 'HARD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Monster Slayer Cash',
         unit: 'MSC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'HyperAlloy',
         unit: 'ALLOY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Shield Protocol',
         unit: 'SHIELD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'AllianceBlock Token',
         unit: 'bALBT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BR34P',
         unit: 'BR34P',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Soak Token',
         unit: 'SOAK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Tardigrades.Finance',
         unit: 'TRDG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Taco',
         unit: 'TACO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ramen Token',
         unit: 'Ramen',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'yieldwatch',
         unit: 'WATCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SWGb',
         unit: 'SWGb',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'YVS.Finance on BSC',
         unit: 'YVS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSCstarter',
         unit: 'START',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BoringDAO Token',
         unit: 'BOR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Birthday Cake',
         unit: 'BDAY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Gambit',
         unit: 'GMT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Gemstone Token',
         unit: 'GST',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Operand',
         unit: 'OPERAND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'VIDT Datalink',
         unit: 'VIDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'thesmokehouse.finance',
         unit: 'SMOKE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ZCore Finance',
         unit: 'ZEFI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'VikingSwap Token',
         unit: 'VIKING',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Antimatter.Finance Mapping Token',
         unit: 'MATTER',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SHAKE token by SpaceSwap v2',
         unit: 'SHAKE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MilkyWay Token by SpaceSwap v2',
         unit: 'MILK2',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Dusk Network',
         unit: 'DUSK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PEAKDEFI',
         unit: 'PEAK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSC FARM',
         unit: 'BSC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'pTokens OPIUM',
         unit: 'pOPIUM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pinelix',
         unit: 'PNL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CheesecakeSwap Token',
         unit: 'CCAKE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MacaronSwap Token',
         unit: 'MCRN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Kindcow Finance',
         unit: 'KIND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TIN',
         unit: 'TINFOIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ERC20',
         unit: 'ERC20',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SPONGE',
         unit: 'SPG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ZD',
         unit: 'ZD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TOOLS',
         unit: 'TOOLS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BLinkToken',
         unit: 'blink',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'YieldPanda.finance',
         unit: 'yPANDA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Fatfi Protocol',
         unit: 'FAT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Jiggly',
         unit: 'JIGG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SafeStar',
         unit: 'SAFESTAR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DeXe',
         unit: 'DEXE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TREAT',
         unit: 'TREAT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BUX Token',
         unit: 'BUX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'xWIN Token',
         unit: 'XWIN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DIESEL TOKEN',
         unit: 'DIESEL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Milktea Finance',
         unit: 'MTF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Tutti Frutti',
         unit: 'TFF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DeFireX on BSC',
         unit: 'DFX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bamboo Token',
         unit: 'BBOO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pineapple',
         unit: 'PIN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Swampy',
         unit: 'SWAMP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'FEB Token',
         unit: 'FEB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'NerveNetwork',
         unit: 'NVT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Yetucoin',
         unit: 'YETU',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BerrySwap Token',
         unit: 'Berry',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Friction Finance',
         unit: 'TAO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Octree Finance',
         unit: 'OCT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SafeMoon',
         unit: 'SAFEMOON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'GFORCE',
         unit: 'GFCE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Whirl Finance',
         unit: 'WHIRL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Monster Slayer Share',
         unit: 'MSS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ArgonToken',
         unit: 'ARGON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bingo Cash',
         unit: 'BGO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TokenPocket Token',
         unit: 'TPT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PolyCrowns',
         unit: 'pCWS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Slime',
         unit: 'SLME',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UniTrade',
         unit: 'TRADE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'FullSail Finance Token',
         unit: 'SAIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Polaris',
         unit: 'POLAR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'blizzard.money',
         unit: 'BLZD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Stronk Alpaca',
         unit: 'sALPACA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BrickChain',
         unit: 'BRICK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'bns.finance',
         unit: 'BNSD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'vSWAP.fi',
         unit: 'vBSWAP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UpBots',
         unit: 'UBXT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ellipsis',
         unit: 'EPS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MoonDao',
         unit: 'MNDAO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PoFi',
         unit: 'PoFi',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Badger Sett Digg',
         unit: 'bDIGG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'IRON Stablecoin',
         unit: 'IRON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SUPER-ERC20',
         unit: 'SUPER',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cyclone Protocol',
         unit: 'CYC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Chip',
         unit: 'CHIP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'VANCAT Token',
         unit: 'VANCAT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'srnArtGallery',
         unit: 'SACT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Astronaut',
         unit: 'NAUT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Typhoon',
         unit: 'TYPH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'HOGL Finance',
         unit: 'HOGL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Titanic Token',
         unit: 'TIT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Switcheo Token',
         unit: 'SWTH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Badger Sett Badger',
         unit: 'bBADGER',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSC Wrapped Jupiter',
         unit: 'bwJUP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'farm.space',
         unit: 'SPACE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Palm Token',
         unit: 'PALM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Elrond',
         unit: 'EGLD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Thunder Token',
         unit: 'TNDR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'IRON Share V2',
         unit: 'STEEL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Tixl Token',
         unit: 'TXL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'QUAMNETWORK.COM',
         unit: 'QUAM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Elastic BNB',
         unit: 'XBN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Underdog.Finance',
         unit: 'DOG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UNICORN Token',
         unit: 'UNICORN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BlueToken',
         unit: 'BLUE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TORJ.world',
         unit: 'TORJ',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'HappinessToken',
         unit: 'HPS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'HYDRO TOKEN',
         unit: 'HYDRO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'AceD Entertainment',
         unit: 'AceD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Venus ADA',
         unit: 'vADA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cryptium Temporary Token Public',
         unit: 'CRPTP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ACryptoS(I)',
         unit: 'ACSI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Alien Worlds Trilium',
         unit: 'TLM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Uniswap Finance',
         unit: 'UNFI_1',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bondly Token',
         unit: 'BONDLY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Eleven.finance',
         unit: 'ELE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Mountain - Climb Token Finance',
         unit: 'MNTN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Climb Token Finance',
         unit: 'CLIMB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Mobox',
         unit: 'MBOX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Swirl.Cash',
         unit: 'SWIRL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Magic Balancer',
         unit: 'MGB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'XSPACE',
         unit: 'XSPACE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Poly-Peg COOK',
         unit: 'COOK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Midas Gold',
         unit: 'MDG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ITAM',
         unit: 'ITAM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'WardenSwap Token',
         unit: 'Warden',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CyberTime Finance Token',
         unit: 'CTF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Tokocrypto Token',
         unit: 'TKO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SeedifyFund',
         unit: 'SFUND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'NFTL Token',
         unit: 'NFTL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Fuse Token on BSC',
         unit: 'FUSE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Fox Finance',
         unit: 'FOX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Zero.Exchange Token',
         unit: 'ZERO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ANY Ethereum',
         unit: 'anyETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ANY Bitcoin',
         unit: 'anyBTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Frenchie',
         unit: 'FREN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Juventus',
         unit: 'JUV',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Reference System for DeFi',
         unit: 'RSD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Exeedme',
         unit: 'XED',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'APOyield SOULS',
         unit: 'SOUL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Rupee Token',
         unit: 'RUPEE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Ball Token',
         unit: 'BALL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SafeGalaxy',
         unit: 'SAFEGALAXY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MarshmallowDeFi Token',
         unit: 'MASH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Moon Rat Token',
         unit: 'MRAT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SafeMars',
         unit: 'SAFEMARS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BGOV Token',
         unit: 'BGOV',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Safe Protocol',
         unit: 'SAFEP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Standard on xDai on BSC',
         unit: 'xMARK',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Fair Safe',
         unit: 'FSAFE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SafeBTC',
         unit: 'SAFEBTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Aquagoat',
         unit: 'AQUAGOAT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pig Token',
         unit: 'PIG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Lime Token',
         unit: 'LIME',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Neonic',
         unit: 'NEON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Eclipse',
         unit: 'ECP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Moon Token',
         unit: 'MOONTOKEN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ElonGate',
         unit: 'ElonGate',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MochiSwap Token',
         unit: 'MOCHI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'pDollar',
         unit: 'PDO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DeFi For You.',
         unit: 'DFY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSC Conflux',
         unit: 'bCFX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'The Force Token',
         unit: 'FOR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Zilliqa',
         unit: 'ZIL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DuckDaoDime',
         unit: 'DDIM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Moeda Loyalty Points',
         unit: 'MDA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Octans',
         unit: 'OCTA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SYL',
         unit: 'SYL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pika Finance',
         unit: 'PIKA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'LPT Pair',
         unit: 'LPTP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BondAppetit Governance',
         unit: 'bBAG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Nerve',
         unit: 'NRV',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CryptEx Token',
         unit: 'CRX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PolkastarterToken',
         unit: 'POLS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BelugaToken',
         unit: 'BELUGA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pet Token',
         unit: 'PET',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bourbon Barrel Token',
         unit: 'BRRL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'IceToken',
         unit: 'ICE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'XEND',
         unit: 'XEND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BSCS Token',
         unit: 'BSCS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'WenMoon Token',
         unit: 'WENMOON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Modefi',
         unit: 'MOD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Finminity',
         unit: 'FMT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MoonMoon',
         unit: 'MOONMOON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bogged Finance',
         unit: 'BOG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Gen Token',
         unit: 'GEN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MoMo KEY',
         unit: 'KEY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Refinable',
         unit: 'FINE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UnmarshalToken',
         unit: 'MARSH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'WaultSwap',
         unit: 'WEX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Hakka Finance on xDai on BSC',
         unit: 'HAKKA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'FARM Reward Token',
         unit: 'FARM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'GreenToken',
         unit: 'GREEN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'RAMP DEFI',
         unit: 'RAMP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'VANGOLD',
         unit: 'VGD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SmartPool Token',
         unit: 'SPOOL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Sea Token',
         unit: 'SEA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Cub Finance',
         unit: 'CUB',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BNbitcoin Token - minable bitcoin on BSC',
         unit: 'BNBTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SAFESPACE',
         unit: 'SAFESPACE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MoonStar',
         unit: 'MOONSTAR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'LunarHighway',
         unit: 'LUNAR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'NFTArt.Finance',
         unit: 'NFTART',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TrueUSD',
         unit: 'TUSD',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'BEP20 LEO',
         unit: 'bLEO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Unified',
         unit: 'UNIF',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SOMIDAX',
         unit: 'SMDX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Bingus Token',
         unit: 'BINGUS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ROOBEE',
         unit: 'bROOBEE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'OakTree Token',
         unit: 'TREE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: '8PAY Network',
         unit: '8PAY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Rug Busters ',
         unit: 'RUGBUST',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'CumRocket',
         unit: 'CUMMIES',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Lottery Token',
         unit: 'LOT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Graviton',
         unit: 'GTON',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Poodl',
         unit: 'POODL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Summit Koda Token',
         unit: 'KODA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Super Launcher',
         unit: 'LAUNCH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'loser coin',
         unit: 'lowb',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TeraBlock Token',
         unit: 'TBC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Kai Inu',
         unit: 'KaiInu',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ZETH',
         unit: 'ZETH',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ZBTC',
         unit: 'ZBTC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ICA',
         unit: 'ICA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'FastSwapToken',
         unit: 'FAST',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'DOGGY',
         unit: 'DOGGY',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UniCrypt on xDai on BSC',
         unit: 'UNCX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Perlin',
         unit: 'PERL',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MANTRA DAO',
         unit: 'OM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Tezos Token',
         unit: 'XTZ',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Porn',
         unit: 'PORN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'SUPERMOON',
         unit: 'OSM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Matador Token',
         unit: 'MTDR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PEACOCKCOIN',
         unit: 'PEKC',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Xenon Pay II',
         unit: 'X2P',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PRIVATEUM',
         unit: 'PVM',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Wootrade Network',
         unit: 'WOO',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Neutrino USD',
         unit: 'USDN',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Pacoca',
         unit: 'PACOCA',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ChipShop Token',
         unit: 'CHIPS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PAPR',
         unit: 'PAPR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'PRNTR',
         unit: 'PRNTR',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Binance Ecosystem Value',
         unit: 'BEV',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Longdrink Finance',
         unit: 'LONG',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'MoonRise',
         unit: 'MOONRISE',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'OLYMPUS',
         unit: 'OLYMPUS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'WolfSafePoorPeople',
         unit: 'WSPP',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UNFI',
         unit: 'UNFI',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'TFT on BSC',
         unit: 'TFT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Moonpot',
         unit: 'POTS',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'GreenTrust',
         unit: 'GNT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'Landshare Token',
         unit: 'LAND',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'ARIVA',
         unit: 'ARV',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
   {
      from: {
         name: 'UniCrypt',
         unit: 'UNCX',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
      to: {
         name: 'TetherUS',
         unit: 'USDT',
         change: 0,
         image: 'https://via.placeholder.com/32',
      },
   },
]
