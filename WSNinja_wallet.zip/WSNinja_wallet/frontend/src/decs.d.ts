declare module 'react-tradingview-widget';
declare module 'qrcode-reader';
