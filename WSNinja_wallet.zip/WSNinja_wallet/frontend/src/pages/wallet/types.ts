export type ICoinTab = 'History' | 'Send' | 'Receive';

export type IHistoryFilter = 'all' | 'received' | 'sent' | 'exchanged' | 'call';
