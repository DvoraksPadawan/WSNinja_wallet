# WSNinja_wallet

Integration of TON wallet into WSNinja wallet

TBD:
- Deployment script for TON wallet
- 


