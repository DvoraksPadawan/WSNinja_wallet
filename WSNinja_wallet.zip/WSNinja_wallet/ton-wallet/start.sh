# TON Center API key for website wallet used for mainnet
# Required for any task and target
export TONCENTER_API_KEY_WEB_MAIN=4f96a149e04e0821d20f9e99ee716e20ff52db7238f38663226b1c0f303003e0
# TON Center API key for website wallet used for testnet
# Required for any task and target
export TONCENTER_API_KEY_WEB_TEST=4f96a149e04e0821d20f9e99ee716e20ff52db7238f38663226b1c0f303003e0
# TON Center API key for extension wallet used for mainnet
# Required for any task and target
export TONCENTER_API_KEY_EXT_MAIN=503af517296765c3f1729fcb301b063a00650a50a881eeaddb6307d5d45e21aa
# TON Center API key for extension wallet used for testnet
# Required for any task and target
export TONCENTER_API_KEY_EXT_TEST=503af517296765c3f1729fcb301b063a00650a50a881eeaddb6307d5d45e21aa

# Start web server for test website wallet version port
# If not exists or empty used default port 8080
export START_WEB_PORT=8081

# NEXT VALUES NO NEED NOW, ITS FOR PUBLISH TASK IN FUTURE
# Mozilla addons.mozilla.org API key to sign packed extension
# Required for "publish" task and "firefox" target
export MOZILLA_ADDONS_API_KEY=user:12345678:123
# Mozilla addons.mozilla.org API secret to sign packed extension
# Required for "publish" task and "firefox" target
export MOZILLA_ADDONS_API_SECRET=0000000000000000000000000000000000000000000000000000000000000000
# Mozilla addons.mozilla.org extension identifier
# Required for "publish" task and "firefox" target
export MOZILLA_EXTENSION_ID={00000000-0000-0000-0000-000000000000}

#gulp start --gulpfile build/gulpfile.js --cwd . --target web

gulp build --gulpfile build/gulpfile.js --cwd . --target web

#gulp build --gulpfile build/gulpfile.js --cwd . --target firefox

#npm run build web

